<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Role Management</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createRoleModal">
                        Create New Role
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($role->name); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-view')): ?>
                                    <button class="btn btn-info" data-bs-toggle="modal"
                                        data-bs-target="#showRoleModal<?php echo e($role->id); ?>">Show</button>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-update')): ?>
                                    <button class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editRoleModal<?php echo e($role->id); ?>">Edit</button>
                                <?php endif; ?>

                                <?php echo Form::open([
                                    'method' => 'DELETE',
                                    'route' => ['roles.destroy', $role->id],
                                    'style' => 'display:inline',
                                    'onsubmit' => 'return confirmDelete()',
                                ]); ?>

                                <button type="submit" class="btn btn-outline-danger" style="border:none;"
                                    onclick="return confirm('Are you sure you want to delete this role?')">
                                    <i class="fa-solid fa-trash-can fa-lg"></i>
                                </button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>

                        <div class="modal fade" id="showRoleModal<?php echo e($role->id); ?>" tabindex="-1"
                            aria-labelledby="showRoleModalLabel<?php echo e($role->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="showRoleModalLabel<?php echo e($role->id); ?>">Show Role</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Name:</strong> <?php echo e($role->name); ?></p>
                                        <p><strong>Permissions:</strong></p>
                                        <ul>
                                            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($permission->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="editRoleModal<?php echo e($role->id); ?>" tabindex="-1"
                            aria-labelledby="editRoleModalLabel<?php echo e($role->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editRoleModalLabel<?php echo e($role->id); ?>">Edit Role</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo Form::model($role, [
                                            'method' => 'PATCH',
                                            'route' => ['roles.update', $role->id],
                                            'id' => 'editRoleForm' . $role->id,
                                        ]); ?>

                                        <div class="form-group">
                                            <strong>Name:</strong>
                                            <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'editRoleName' . $role->id]); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>Permission:</strong>
                                            <br />
                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label for="permission<?php echo e($permission->id); ?>">
                                                    <?php echo e(Form::checkbox('permissions[]', $permission->id, in_array($permission->id, $role->permissions->pluck('id')->toArray()), ['class' => 'edit-permission', 'id' => 'permission' . $permission->id])); ?>

                                                    <?php echo e($permission->name); ?>

                                                </label>
                                                <br />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                        <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Role Modal -->
    <div class="modal fade" id="createRoleModal" tabindex="-1" aria-labelledby="createRoleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createRoleModalLabel">Create New Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('roles.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <strong>Name:</strong>
                            <input type="text" name="name" placeholder="Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <strong>Permission:</strong>
                            <br />
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="permission<?php echo e($permission->id); ?>">
                                    <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>"
                                        class="create-permission" id="permission<?php echo e($permission->id); ?>">
                                    <?php echo e($permission->name); ?>

                                </label>
                                <br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/roles/index.blade.php ENDPATH**/ ?>