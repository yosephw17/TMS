 <!-- Project Tab -->
 <div class="tab-pane fade show active" id="project<?php echo e($project->id); ?>" role="tabpanel"
     aria-labelledby="project-tab<?php echo e($project->id); ?>">
     <div class="mt-3">

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Starting Date:</strong>
             <p class="lead"><?php echo e(\Carbon\Carbon::parse($project->starting_date)->format('F d, Y')); ?>

             </p>
         </div>

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Ending Date:</strong>
             <p class="lead">
                 <?php echo e($project->ending_date ? \Carbon\Carbon::parse($project->ending_date)->format('F d, Y') : 'Ongoing'); ?>

             </p>
         </div>

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Description:</strong>
             <p class="lead"><?php echo e($project->description); ?></p>
         </div>

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Location:</strong>
             <p class="lead"><?php echo e($project->location); ?></p>
         </div>

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Services Included:</strong>
             <?php if($project->serviceDetails->count() > 0): ?>
                 <ul class="list-group">
                     <?php $__currentLoopData = $project->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li class="list-group-item">
                             <?php echo e($serviceDetail->detail_name); ?> (under
                             <?php echo e($serviceDetail->service->name); ?>)
                         </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>
             <?php else: ?>
                 <p class="text-muted">None</p>
             <?php endif; ?>
         </div>

         <div class="mb-3">
             <strong class="font-weight-bold mb-1">Status:</strong>
             <p class="lead">
                 <span
                     class="<?php echo e($project->status == 'completed' ? 'text-success' : ($project->status == 'canceled' ? 'text-danger' : 'text-warning')); ?>">
                     <?php echo e(ucfirst($project->status)); ?>

                 </span>
             </p>
         </div>
     </div>
 </div>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/projectTab.blade.php ENDPATH**/ ?>