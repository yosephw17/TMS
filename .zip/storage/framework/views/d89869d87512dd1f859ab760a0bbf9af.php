<?php $__env->startSection('content'); ?>
    <h4>Proforma Images for <?php echo e($seller->name); ?></h4>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-image-create')): ?>
        <button class="btn btn-success mb-4" data-bs-toggle="modal" data-bs-target="#addProformaModal">
            Add Proforma Image
        </button>
    <?php endif; ?>

    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $proformaImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proforma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Proforma Type: <?php echo e($proforma->proforma_type); ?></h5>
                            <p>Seller: <?php echo e($seller->name); ?></p>
                            <p>Phone: <?php echo e($seller->phone); ?></p>
                        </div>
                        <div class="card-body">
                            <a href="<?php echo e(asset('storage/' . $proforma->image_path)); ?>" target="_blank">
                                <img src="<?php echo e(asset('storage/' . $proforma->image_path)); ?>" alt="Proforma Image"
                                    style="width: 100%; height: auto;" class="img-thumbnail">
                            </a>

                            <?php if($proforma->project): ?>
                                <h6>Related Project:</h6>
                                <p><strong><?php echo e($proforma->project->name); ?></strong></p>
                            <?php endif; ?>
                            <p>Status: <strong><?php echo e(ucfirst($proforma->status)); ?></strong></p>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <form action="<?php echo e(route('proforma_images.approve', $proforma->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-image-approve')): ?>
                                    <button type="submit" class="btn btn-success btn-sm">
                                        Approve
                                    </button>
                                <?php endif; ?>
                            </form>

                            <form action="<?php echo e(route('proforma_images.decline', $proforma->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-image-decline')): ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Decline
                                    </button>
                                <?php endif; ?>
                            </form>

                            <form action="<?php echo e(route('proforma_images.destroy', $proforma->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-image-delete')): ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this image?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <div class="modal fade" id="addProformaModal" tabindex="-1" aria-labelledby="addProformaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addProformaModalLabel">Add Proforma Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('proforma_images.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">

                        <div class="form-group">
                            <label for="project_id">Select Project</label>
                            <select name="project_id" class="form-control" required>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <label for="type">Proforma Type</label>
                            <select name="type" class="form-control" required>
                                <option value="aluminium">Aluminium</option>
                                <option value="finishing">Finishing</option>
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <label for="image">Proforma Image</label>
                            <input type="file" name="image" class="form-control" required>
                        </div>

                        <div class="mt-3 text-center">
                            <button type="submit" class="btn btn-success">Upload Proforma</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/sellers/show.blade.php ENDPATH**/ ?>