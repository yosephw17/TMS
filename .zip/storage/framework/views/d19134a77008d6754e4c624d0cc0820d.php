  <!-- Work Proforma Content -->
  <div class="tab-pane fade" id="workProforma<?php echo e($project->id); ?>" role="tabpanel"
      aria-labelledby="work-tab<?php echo e($project->id); ?>">
      <div class="card mt-3">

          <div class="card-body">
              <button class="btn btn-primary mb-3" data-bs-toggle="modal"
                  data-bs-target="#addWorkProformaModal<?php echo e($project->id); ?>">
                  Add Proforma
              </button>

              <?php if($workProformas->isEmpty()): ?>
                  <p>No Work Proformas available.</p>
              <?php else: ?>
                  <table class="table table-bordered">
                      <thead>
                          <tr>
                              <th>Ref No</th>
                              <th>Date</th>
                              <th>Before VAT Total</th>
                              <th>VAT Percentage</th>
                              <th>After VAT Total</th>
                              <th>Discount</th>
                              <th>Final Total</th>
                              <th>Actions</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $workProformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proforma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($proforma->type === 'work'): ?>
                                  <!-- Main Proforma Row -->
                                  <tr data-bs-toggle="collapse" data-bs-target="#collapseProforma<?php echo e($proforma->id); ?>"
                                      aria-expanded="false">
                                      <td><?php echo e($proforma->ref_no); ?></td>
                                      <td><?php echo e($proforma->date->format('F d, Y')); ?></td>
                                      <td><?php echo e($proforma->before_vat_total); ?></td>
                                      <td><?php echo e($proforma->vat_percentage); ?>%</td>
                                      <td><?php echo e($proforma->after_vat_total); ?></td>
                                      <td><?php echo e($proforma->discount); ?></td>
                                      <td><?php echo e($proforma->final_total); ?></td>
                                      <td>
                                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-edit')): ?>
                                              <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal"
                                                  data-bs-target="#editWorkProformaModal<?php echo e($proforma->id); ?>">
                                                  Edit
                                              </button>
                                          <?php endif; ?>
                                          <form action="<?php echo e(route('proforma_work.destroy', $proforma->id)); ?>"
                                              method="POST" style="display:inline;">
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('DELETE'); ?>
                                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-delete')): ?>
                                                  <button type="submit" class="btn btn-outline-danger btn-sm"
                                                      onclick="return confirm('Are you sure you want to delete?')">
                                                      Delete
                                                  </button>
                                              <?php endif; ?>
                                          </form>
                                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-print')): ?>
                                              <a href="<?php echo e(route('print.work', $proforma->id)); ?>" class="btn btn-secondary"
                                                  target="_blank"
                                                  onclick="event.preventDefault(); window.open(this.href, '_blank'); return false;">
                                                  <i class="fas fa-print"></i>
                                                  Print
                                              </a>
                                          <?php endif; ?>
                                      </td>
                                  </tr>

                                  <tr class="collapse bg-light" id="collapseProforma<?php echo e($proforma->id); ?>">
                                      <td colspan="8">
                                          <div class="p-3">
                                              <h6>Work Proforma Details</h6>
                                              <table class="table table-sm">
                                                  <thead>
                                                      <tr>
                                                          <th>Name</th>
                                                          <th>Unit</th>
                                                          <th>Amount</th>
                                                          <th>Quantity</th>
                                                          <th>Total Price</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody>
                                                      <?php $__currentLoopData = $proforma->works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <tr>
                                                              <td><?php echo e($work->work_name); ?></td>
                                                              <td><?php echo e($work->work_unit); ?></td>
                                                              <td><?php echo e(number_format($work->work_amount, 2)); ?></td>
                                                              <td><?php echo e($work->work_quantity); ?></td>
                                                              <td><?php echo e(number_format($work->work_total, 2)); ?>

                                                              </td>
                                                          </tr>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </tbody>
                                              </table>

                                              <div class="row mt-4">
                                                  <div class="col-md-6">
                                                      <p><strong>Payment Validity:</strong>
                                                          <?php echo e($proforma->payment_validity); ?></p>
                                                      <p><strong>Delivery Terms:</strong>
                                                          <?php echo e($proforma->delivery_terms); ?></p>
                                                  </div>
                                                  <div class="col-md-6 text-end">
                                                      <table class="table table-borderless">
                                                          <tr>
                                                              <th>Subtotal (Before VAT):</th>
                                                              <td><?php echo e(number_format($proforma->before_vat_total, 2)); ?>

                                                              </td>
                                                          </tr>
                                                          <tr>
                                                              <th>VAT (<?php echo e($proforma->vat_percentage); ?>%):</th>
                                                              <td><?php echo e(number_format($proforma->vat_amount, 2)); ?></td>
                                                          </tr>
                                                          <tr>
                                                              <th>After VAT Total:</th>
                                                              <td><?php echo e(number_format($proforma->after_vat_total, 2)); ?>

                                                              </td>
                                                          </tr>
                                                          <tr>
                                                              <th>Discount:</th>
                                                              <td><?php echo e(number_format($proforma->discount ?? 0, 2)); ?></td>
                                                          </tr>
                                                          <tr>
                                                              <th><strong>Final Total:</strong></th>
                                                              <td><strong><?php echo e(number_format($proforma->final_total, 2)); ?></strong>
                                                              </td>
                                                          </tr>
                                                      </table>
                                                  </div>
                                              </div>
                                          </div>
                                      </td>
                                  </tr>

                                  <!-- Edit Work Proforma Modal -->
                                  <div class="modal fade" id="editWorkProformaModal<?php echo e($proforma->id); ?>" tabindex="-1"
                                      aria-labelledby="editWorkProformaModalLabel<?php echo e($proforma->id); ?>"
                                      aria-hidden="true">
                                      <div class="modal-dialog modal-lg">
                                          <form action="<?php echo e(route('proforma_work.update', $proforma->id)); ?>"
                                              method="POST">
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('PUT'); ?>
                                              <div class="modal-content">
                                                  <div class="modal-header">
                                                      <h5 class="modal-title"
                                                          id="editWorkProformaModalLabel<?php echo e($proforma->id); ?>">
                                                          Edit Work Proforma
                                                      </h5>
                                                      <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                          aria-label="Close"></button>
                                                  </div>
                                                  <div class="modal-body">
                                                      <input type="hidden" name="project_id"
                                                          value="<?php echo e($project->id); ?>">
                                                      <input type="hidden" name="customer_id"
                                                          value="<?php echo e($project->customer_id); ?>">

                                                      <div class="form-group mb-3">
                                                          <label for="type">Type</label>
                                                          <select name="type" class="form-control" required>
                                                              <option value="Aluminium"
                                                                  <?php echo e($proforma->type == 'Aluminium' ? 'selected' : ''); ?>>
                                                                  Aluminium</option>
                                                              <option value="Finishing"
                                                                  <?php echo e($proforma->type == 'Finishing' ? 'selected' : ''); ?>>
                                                                  Finishing</option>
                                                          </select>
                                                      </div>

                                                      <div class="form-group mb-3">
                                                          <label for="ref_no">Reference Number</label>
                                                          <input type="text" name="ref_no" class="form-control"
                                                              value="<?php echo e($proforma->ref_no); ?>"
                                                              placeholder="Enter reference number" required>
                                                      </div>

                                                      <div class="form-group mb-3">
                                                          <label for="date">Date</label>
                                                          <input type="date" name="date" class="form-control"
                                                              value="<?php echo e($proforma->date); ?>" required>
                                                      </div>

                                                      <div class="form-group mb-3">
                                                          <label for="discount">Discount</label>
                                                          <input type="number" name="discount" class="form-control"
                                                              value="<?php echo e($proforma->discount); ?>"
                                                              placeholder="Enter discount (if any)">
                                                      </div>
                                                      <div class="form-group mb-3">
                                                          <label for="vat_percentage">VAT Percentage</label>
                                                          <input type="number" name="vat_percentage"
                                                              class="form-control"
                                                              value="<?php echo e($proforma->vat_percentage); ?>" required>
                                                      </div>

                                                      <div class="form-group mb-3">
                                                          <label for="payment_validity">Payment Validity</label>
                                                          <input type="text" name="payment_validity"
                                                              class="form-control"
                                                              value="<?php echo e($proforma->payment_validity); ?>"
                                                              placeholder="Enter payment validity">
                                                      </div>
                                                      <div class="form-group mb-3">
                                                          <label for="delivery_terms">Delivery Terms</label>
                                                          <input type="text" name="delivery_terms"
                                                              class="form-control"
                                                              value="<?php echo e($proforma->delivery_terms); ?>"
                                                              placeholder="Enter delivery terms">
                                                      </div>

                                                      <div id="editWorkEntriesContainer">
                                                          <?php $__currentLoopData = $proforma->works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <div class="work-entry mb-3">
                                                                  <h6>Work Entry <?php echo e($index + 1); ?></h6>
                                                                  <input type="hidden"
                                                                      name="works[<?php echo e($index); ?>][id]"
                                                                      value="<?php echo e($work->id); ?>">

                                                                  <div class="form-group">
                                                                      <label for="work_name[]">Name</label>
                                                                      <input type="text"
                                                                          name="works[<?php echo e($index); ?>][name]"
                                                                          class="form-control"
                                                                          value="<?php echo e(old('works.' . $index . '.name', $work->work_name)); ?>"
                                                                          placeholder="Enter work name" required>
                                                                  </div>
                                                                  <div class="form-group">
                                                                      <label for="work_unit[]">Unit</label>
                                                                      <input type="text"
                                                                          name="works[<?php echo e($index); ?>][unit]"
                                                                          class="form-control"
                                                                          value="<?php echo e(old('works.' . $index . '.unit', $work->work_unit)); ?>"
                                                                          placeholder="Enter unit" required>
                                                                  </div>
                                                                  <div class="form-group">
                                                                      <label for="work_amount[]">Amount</label>
                                                                      <input type="number"
                                                                          name="works[<?php echo e($index); ?>][amount]"
                                                                          class="form-control"
                                                                          value="<?php echo e(old('works.' . $index . '.amount', $work->work_amount)); ?>"
                                                                          placeholder="Enter amount" required>
                                                                  </div>
                                                                  <div class="form-group">
                                                                      <label for="work_quantity[]">Quantity</label>
                                                                      <input type="number"
                                                                          name="works[<?php echo e($index); ?>][quantity]"
                                                                          class="form-control"
                                                                          value="<?php echo e(old('works.' . $index . '.quantity', $work->work_quantity)); ?>"
                                                                          placeholder="Enter quantity" required>
                                                                  </div>
                                                                  <div class="form-group">
                                                                      <label for="work_total[]">Total</label>
                                                                      <input type="number"
                                                                          name="works[<?php echo e($index); ?>][total]"
                                                                          class="form-control"
                                                                          value="<?php echo e(old('works.' . $index . '.total', $work->work_total)); ?>"
                                                                          placeholder="Total">
                                                                  </div>
                                                              </div>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </div>

                                                  </div>
                                                  <div class="modal-footer">
                                                      <button type="button" class="btn btn-secondary"
                                                          data-bs-dismiss="modal">Close</button>
                                                      <button type="submit" class="btn btn-primary">Update
                                                          Proforma</button>
                                                  </div>
                                              </div>
                                          </form>
                                      </div>
                                  </div>
                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              <?php endif; ?>
          </div>

      </div>
  </div>
  <!-- Add Work Proforma Modal -->
  <div class="modal fade" id="addWorkProformaModal<?php echo e($project->id); ?>" tabindex="-1"
      aria-labelledby="addWorkProformaModalLabel<?php echo e($project->id); ?>" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <form action="<?php echo e(route('proforma_work.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="addWorkProformaModalLabel<?php echo e($project->id); ?>">Add Work Proforma
                      </h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                      <input type="hidden" name="customer_id" value="<?php echo e($project->customer_id); ?>">

                      <div class="form-group mb-3">
                          <label for="type">Type</label>
                          <select name="type" class="form-control" required>
                              <option value="Aluminium">Aluminium</option>
                              <option value="Finishing">Finishing</option>
                          </select>
                      </div>

                      <div class="form-group mb-3">
                          <label for="ref_no">Reference Number</label>
                          <input type="text" name="ref_no" class="form-control"
                              placeholder="Enter reference number" required>
                      </div>

                      <div class="form-group mb-3">
                          <label for="date">Date</label>
                          <input type="date" name="date" class="form-control" required>
                      </div>

                      <div class="form-group mb-3">
                          <label for="discount">Discount</label>
                          <input type="number" name="discount" class="form-control"
                              placeholder="Enter discount (if any)">
                      </div>
                      <div class="form-group mb-3">
                          <label for="vat_percentage">VAT Percentage</label>
                          <input type="number" name="vat_percentage" value="15" class="form-control">
                      </div>

                      <div class="form-group mb-3">
                          <label for="payment_validity">Payment Validity</label>
                          <input type="text" name="payment_validity" class="form-control"
                              placeholder="Enter payment validity">
                      </div>
                      <div class="form-group mb-3">
                          <label for="delivery_terms">Delivery Terms</label>
                          <input type="text" name="delivery_terms" class="form-control"
                              placeholder="Enter delivery terms">
                      </div>

                      <div id="addWorkEntriesContainer">
                          <div class="work-entry mb-3">
                              <h6>Work Entry</h6>
                              <div class="form-group">
                                  <label for="work_name[]">Name</label>
                                  <input type="text" name="works[0][name]" class="form-control"
                                      placeholder="Enter work name" required>
                              </div>
                              <div class="form-group">
                                  <label for="work_unit[]">Unit</label>
                                  <input type="text" name="works[0][unit]" class="form-control"
                                      placeholder="Enter unit" required>
                              </div>
                              <div class="form-group">
                                  <label for="work_amount[]">Amount</label>
                                  <input type="number" name="works[0][amount]" class="form-control"
                                      placeholder="Enter amount" required>
                              </div>
                              <div class="form-group">
                                  <label for="work_quantity[]">Quantity</label>
                                  <input type="number" name="works[0][quantity]" class="form-control"
                                      placeholder="Enter quantity" required>
                              </div>
                              <div class="form-group">
                                  <label for="work_total[]">Total</label>
                                  <input type="number" name="works[0][total]" class="form-control"
                                      placeholder="Total">
                              </div>
                          </div>
                      </div>
                      <button type="button" id="addWorkEntryBtn" class="btn btn-secondary mb-3">Add Another Work
                          Entry</button>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save Proforma</button>
                  </div>
              </div>
          </form>
      </div>
  </div>

  <script>
      let addWorkEntryIndex = 1;
      // Add new work entry in Add Modal
      document.getElementById('addWorkEntryBtn').addEventListener('click', function() {
          const addContainer = document.getElementById('addWorkEntriesContainer');
          const newWorkEntry = createWorkEntryHtml(addWorkEntryIndex);
          addContainer.appendChild(newWorkEntry);
          addWorkEntryIndex++;
      });

      function createWorkEntryHtml(index) {
          const entryDiv = document.createElement('div');
          entryDiv.className = 'work-entry mb-3';
          entryDiv.innerHTML = `
            <h6>Work Entry ${index + 1}</h6>
            <div class="form-group">
                <label for="works[${index}][name]">Name</label>
                <input type="text" name="works[${index}][name]" class="form-control" placeholder="Enter work name" required>
            </div>
            <div class="form-group">
                <label for="works[${index}][unit]">Unit</label>
                <input type="text" name="works[${index}][unit]" class="form-control" placeholder="Enter unit" required>
            </div>
            <div class="form-group">
                <label for="works[${index}][amount]">Amount</label>
                <input type="number" name="works[${index}][amount]" class="form-control" placeholder="Enter amount" required>
            </div>
            <div class="form-group">
                <label for="works[${index}][quantity]">Quantity</label>
                <input type="number" name="works[${index}][quantity]" class="form-control" placeholder="Enter quantity" required>
            </div>
            <div class="form-group">
                <label for="works[${index}][total]">Total</label>
                <input type="number" name="works[${index}][total]" class="form-control" placeholder="Total">
            </div>
        `;
          return entryDiv;
      }
  </script>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/workProformaTab.blade.php ENDPATH**/ ?>