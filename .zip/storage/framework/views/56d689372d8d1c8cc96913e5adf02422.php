 <!-- Images Tab -->
 <div class="tab-pane fade" id="images<?php echo e($project->id); ?>" role="tabpanel" aria-labelledby="images-tab<?php echo e($project->id); ?>">
     <div class="mt-3">
         <h5>Upload Project Images</h5>
         <form action="<?php echo e(route('projects.uploadFiles', $project->id)); ?>" method="POST" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             <div class="form-group">
                 <input type="file" name="files[]" class="form-control" accept="image/*" multiple>
                 <small class="form-text text-muted">You can upload multiple images.</small>
             </div>
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-upload-file')): ?>
                 <button type="submit" class="btn btn-primary">Upload</button>
             <?php endif; ?>
         </form>

         <h5 class="mt-4">Uploaded Images</h5>
         <?php if($project->files->count() > 0): ?>
             <div class="row">
                 <?php $__currentLoopData = $project->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if(str_contains($file->file_type, 'image/')): ?>
                         <div class="col-md-4">
                             <div class="card mb-3">
                                 <img src="<?php echo e(Storage::url($file->file_path)); ?>" class="card-img-top"
                                     alt="<?php echo e($file->file_name); ?>">
                                 <div class="card-body">
                                     <h5 class="card-title"><?php echo e($file->file_name); ?></h5>
                                     <a href="<?php echo e(Storage::url($file->file_path)); ?>" class="btn btn-info"
                                         target="_blank">View</a>
                                 </div>
                             </div>
                         </div>
                     <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         <?php else: ?>
             <p>No images uploaded for this project yet.</p>
         <?php endif; ?>
     </div>
 </div>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/imageTab.blade.php ENDPATH**/ ?>