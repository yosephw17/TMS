<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Company Information Settings</h1>

        

        <!-- Display Company Info Boxes -->
        <div class="row">
            <?php $__currentLoopData = $companyInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-9 mx-auto mb-4">
                    <div class="card shadow-sm p-3 mb-3 bg-body rounded">
                        <div class="card-header d-flex justify-content-between align-items-center bg-light">
                            <h5 class="mb-0"><?php echo e($companyInfo->name); ?></h5>
                            <div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting-update')): ?>
                                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#editCompanyInfoModal<?php echo e($companyInfo->id); ?>">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                <?php endif; ?>

                                
                            </div>
                        </div>
                        <div class="card-body ">
                            <!-- Company Logo -->
                            <?php if($companyInfo->logo): ?>
                                <div class="text-center mb-3">
                                    <img src="<?php echo e(asset('storage/' . $companyInfo->logo)); ?>" alt="Company Logo"
                                        class="img-fluid" style="max-height: 150px;">
                                </div>
                            <?php endif; ?>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="card shadow-sm bg-light">
                                        <div class="card-body">
                                            <p><strong><i class="fas fa-phone-alt"></i> Phone:</strong>
                                                <?php echo e($companyInfo->phone); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="card shadow-sm bg-light">
                                        <div class="card-body">
                                            <p><strong><i class="fas fa-fax"></i> Fax:</strong> <?php echo e($companyInfo->fax); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="card shadow-sm bg-light">
                                        <div class="card-body">
                                            <p><strong><i class="fas fa-fax"></i> Po-box:</strong>
                                                <?php echo e($companyInfo->po_box); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="card shadow-sm bg-light">
                                        <div class="card-body">
                                            <p><strong><i class="fas fa-envelope"></i> Email:</strong>
                                                <?php echo e($companyInfo->email); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="card shadow-sm bg-light">
                                        <div class="card-body">
                                            <p><strong><i class="fas fa-quote-right"></i> Motto:</strong>
                                                <?php echo e($companyInfo->motto); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Edit Company Info Modal -->
                <div class="modal fade" id="editCompanyInfoModal<?php echo e($companyInfo->id); ?>" tabindex="-1"
                    aria-labelledby="editCompanyInfoModalLabel<?php echo e($companyInfo->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editCompanyInfoModalLabel<?php echo e($companyInfo->id); ?>">Edit Company
                                    Info</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('settings.update', $companyInfo->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-body">

                                    <div class="mb-3">
                                        <label for="name" class="form-label">Company Name</label>
                                        <input type="text" name="name" class="form-control" id="name"
                                            value="<?php echo e($companyInfo->name); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone</label>
                                        <input type="text" name="phone" class="form-control" id="phone"
                                            value="<?php echo e($companyInfo->phone); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="fax" class="form-label">Fax</label>
                                        <input type="text" name="fax" class="form-control" id="fax"
                                            value="<?php echo e($companyInfo->fax); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="po_box" class="form-label">Po-box</label>
                                        <input type="text" name="po_box" class="form-control" id="po_box"
                                            value="<?php echo e($companyInfo->po_box); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" name="email" class="form-control" id="email"
                                            value="<?php echo e($companyInfo->email); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="motto" class="form-label">Motto</label>
                                        <input type="text" name="motto" class="form-control" id="motto"
                                            value="<?php echo e($companyInfo->motto); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="logo" class="form-label">Company Logo</label>
                                        <input type="file" name="logo" class="form-control" id="logo">
                                        <?php if($companyInfo->logo): ?>
                                            <div class="mt-2">
                                                <img src="<?php echo e(asset('storage/' . $companyInfo->logo)); ?>"
                                                    alt="Current Logo" width="100">
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Add Company Info Modal -->
        <div class="modal fade" id="addCompanyInfoModal" tabindex="-1" aria-labelledby="addCompanyInfoModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addCompanyInfoModalLabel">Add Company Info</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('settings.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="fax" class="form-label">Fax</label>
                                <input type="text" class="form-control" id="fax" name="fax">
                            </div>
                            <div class="mb-3">
                                <label for="po_box" class="form-label">Po-Box</label>
                                <input type="text" class="form-control" id="po_box" name="po_box">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="motto" class="form-label">Motto</label>
                                <input type="text" class="form-control" id="motto" name="motto">
                            </div>
                            <div class="mb-3">
                                <label for="logo" class="form-label">Logo</label>
                                <input type="file" class="form-control" id="logo" name="logo"
                                    accept="image/*">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add Company Info</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/company_info/index.blade.php ENDPATH**/ ?>