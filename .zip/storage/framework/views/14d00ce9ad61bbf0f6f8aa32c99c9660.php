<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Material Management</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material-create')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createMaterialModal">
                        Create New Material
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Symbol</th>
                        <th>Unit Price</th>
                        <th>Unit of Measurement</th>
                        <th>Color</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($material->name); ?></td>
                            <td><?php echo e($material->code); ?></td>
                            <!-- Display image for symbol -->
                            <td>
                                <?php if($material->symbol): ?>
                                    <img src="<?php echo e(asset('storage/' . $material->symbol)); ?>" alt="Symbol" width="50">
                                <?php endif; ?>
                            </td>

                            <td><?php echo e($material->unit_price); ?></td>
                            <td><?php echo e($material->unit_of_measurement); ?></td>
                            <td><?php echo e($material->color); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material-view')): ?>
                                    <button class="btn btn-info" data-bs-toggle="modal"
                                        data-bs-target="#showMaterialModal<?php echo e($material->id); ?>">
                                        Show
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material-edit')): ?>
                                    <button class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editMaterialModal<?php echo e($material->id); ?>">
                                        Edit
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material-delete')): ?>
                                    <button type="button" class="btn btn-outline-danger"
                                        onclick="deleteMaterial(<?php echo e($material->id); ?>)" style="border:none;">
                                        <i class="fa-solid fa-trash-can fa-lg"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Show Material Modal -->
                        <div class="modal fade" id="showMaterialModal<?php echo e($material->id); ?>" tabindex="-1"
                            aria-labelledby="showMaterialModalLabel<?php echo e($material->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="showMaterialModalLabel<?php echo e($material->id); ?>">Show
                                            Material</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Name:</strong> <?php echo e($material->name); ?></p>
                                        <p><strong>Code:</strong> <?php echo e($material->code); ?></p>
                                        <!-- Display symbol image -->
                                        <p><strong>Symbol:</strong> <img src="<?php echo e(asset('storage/' . $material->symbol)); ?>"
                                                alt="Symbol" width="50">
                                        </p>
                                        <p><strong>Unit Price:</strong> <?php echo e($material->unit_price); ?></p>
                                        <p><strong>Unit of Measurement:</strong> <?php echo e($material->unit_of_measurement); ?></p>
                                        <p><strong>Type:</strong> <?php echo e($material->type); ?></p>
                                        <p><strong>Color:</strong> <span
                                                style="background-color: <?php echo e($material->color); ?>; padding: 0.2em 0.6em;"><?php echo e($material->color); ?></span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Edit Material Modal -->
                        <div class="modal fade" id="editMaterialModal<?php echo e($material->id); ?>" tabindex="-1"
                            aria-labelledby="editMaterialModalLabel<?php echo e($material->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editMaterialModalLabel<?php echo e($material->id); ?>">Edit
                                            Material</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('materials.update', $material->id)); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <div class="form-group">
                                                <strong>Name:</strong>
                                                <input type="text" name="name" value="<?php echo e($material->name); ?>"
                                                    class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <strong>Code:</strong>
                                                <input type="text" name="code" value="<?php echo e($material->code); ?>"
                                                    class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <strong>Symbol (Image):</strong>
                                                <input type="file" name="symbol" class="form-control">
                                                <small>Leave blank to keep the current symbol.</small>
                                                <?php if($material->symbol): ?>
                                                    <div class="mt-2">
                                                        <img src="<?php echo e(asset('storage/' . $material->symbol)); ?>"
                                                            alt="Current Symbol" width="50">
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group">
                                                <strong>Unit Price:</strong>
                                                <input type="text" name="unit_price" value="<?php echo e($material->unit_price); ?>"
                                                    class="form-control" required>
                                            </div>

                                            <div class="form-group">
                                                <strong>Unit of Measurement:</strong>
                                                <select name="unit_of_measurement" class="form-control" required>
                                                    <option value="kg"
                                                        <?php echo e($material->unit_of_measurement == 'kg' ? 'selected' : ''); ?>>
                                                        Kilogram (kg)</option>
                                                    <option value="g"
                                                        <?php echo e($material->unit_of_measurement == 'g' ? 'selected' : ''); ?>>Gram
                                                        (g)
                                                    </option>
                                                    <option value="m"
                                                        <?php echo e($material->unit_of_measurement == 'm' ? 'selected' : ''); ?>>Meter
                                                        (m)</option>
                                                    <option value="cm"
                                                        <?php echo e($material->unit_of_measurement == 'cm' ? 'selected' : ''); ?>>
                                                        Centimeter (cm)</option>
                                                    <option value="liter"
                                                        <?php echo e($material->unit_of_measurement == 'liter' ? 'selected' : ''); ?>>
                                                        Liter (L)</option>
                                                    <option value="pcs"
                                                        <?php echo e($material->unit_of_measurement == 'pcs' ? 'selected' : ''); ?>>
                                                        Pieces (pcs)</option>
                                                    <option value="bar"
                                                        <?php echo e($material->unit_of_measurement == 'bar' ? 'selected' : ''); ?>>Bar
                                                        (bar)</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <strong>Color:</strong>
                                                <select name="color" class="form-control">
                                                    <option value="white"
                                                        <?php echo e($material->color == 'white' ? 'selected' : ''); ?>>White</option>
                                                    <option value="black"
                                                        <?php echo e($material->color == 'black' ? 'selected' : ''); ?>>Black</option>
                                                    <option value="red"
                                                        <?php echo e($material->color == 'red' ? 'selected' : ''); ?>>Red</option>
                                                    <option value="blue"
                                                        <?php echo e($material->color == 'blue' ? 'selected' : ''); ?>>Blue</option>
                                                    <option value="green"
                                                        <?php echo e($material->color == 'green' ? 'selected' : ''); ?>>Green</option>
                                                    <option value="yellow"
                                                        <?php echo e($material->color == 'yellow' ? 'selected' : ''); ?>>Yellow
                                                    </option>
                                                </select>
                                            </div>

                                            <!-- Type (Dropdown for Material Type) -->
                                            <div class="form-group mt-3">
                                                <strong>Type:</strong>
                                                <select name="type" class="form-control" required>
                                                    <option value="" disabled>Select Material Type</option>
                                                    <option value="aluminium_profile"
                                                        <?php echo e($material->type == 'aluminium_profile' ? 'selected' : ''); ?>>
                                                        Aluminium Profile</option>
                                                    <option value="aluminium_accessory"
                                                        <?php echo e($material->type == 'aluminium_accessory' ? 'selected' : ''); ?>>
                                                        Aluminium Accessory</option>
                                                    <option value="finishing"
                                                        <?php echo e($material->type == 'finishing' ? 'selected' : ''); ?>>Finishing
                                                    </option>
                                                    <option value="other"
                                                        <?php echo e($material->type == 'other' ? 'selected' : ''); ?>>Other</option>
                                                </select>
                                            </div>

                                            <div class="text-center">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>

    <!-- Create Material Modal -->
    <div class="modal fade" id="createMaterialModal" tabindex="-1" aria-labelledby="createMaterialModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createMaterialModalLabel">Create New Material</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('materials.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <!-- Material Name -->
                        <div class="form-group">
                            <strong>Name:</strong>
                            <input type="text" name="name" placeholder="Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <strong>Code:</strong>
                            <input type="text" name="code" placeholder="Code" class="form-control">
                        </div>

                        <!-- Unit of Measurement -->
                        <div class="form-group mt-3">
                            <strong>Unit of Measurement:</strong>
                            <select name="unit_of_measurement" class="form-control" required>
                                <option value="" disabled selected>Select Unit of Measurement</option>
                                <option value="kg">Kilogram (kg)</option>
                                <option value="g">Gram (g)</option>
                                <option value="m">Meter (m)</option>
                                <option value="cm">Centimeter (cm)</option>
                                <option value="liter">Liter (L)</option>
                                <option value="pcs">Pieces (pcs)</option>
                                <option value="bar">Bar (bar)</option>
                                <!-- Add more units as needed -->
                            </select>
                        </div>

                        <!-- Unit Price -->
                        <div class="form-group mt-3">
                            <strong>Unit Price:</strong>
                            <input type="text" name="unit_price" placeholder="Unit Price" class="form-control"
                                required>
                        </div>

                        <!-- Color (Dropdown with White and Black on Top) -->
                        <div class="form-group mt-3">
                            <strong>Color:</strong>
                            <select name="color" class="form-control">
                                <option value="" disabled selected>Select Color</option>
                                <option value="white">White</option>
                                <option value="black">Black</option>
                                <option value="red">Red</option>
                                <option value="blue">Blue</option>
                                <option value="green">Green</option>
                                <option value="yellow">Yellow</option>
                                <!-- Add more colors as needed -->
                            </select>
                        </div>

                        <!-- Type (Dropdown for Material Type) -->
                        <div class="form-group mt-3">
                            <strong>Type:</strong>
                            <select name="type" class="form-control" required>
                                <option value="" disabled selected>Select Material Type</option>
                                <option value="aluminium_profile">Aluminium Profile</option>
                                <option value="aluminium_accessory">Aluminium Accessory</option>
                                <option value="finishing">Finishing</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <!-- Symbol (Image Upload) -->
                        <div class="form-group mt-3">
                            <strong>Symbol (Upload Image):</strong>
                            <input type="file" name="symbol" class="form-control" accept="image/*">
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center mt-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function deleteMaterial(materialId) {
        if (confirm("Are you sure to delete this material?")) {
            fetch(`materials/${materialId}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert("Failed to delete material.");
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/materials/index.blade.php ENDPATH**/ ?>