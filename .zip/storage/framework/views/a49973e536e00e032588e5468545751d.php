<!-- Proformas Tab -->

<div class="tab-pane fade" id="proformas<?php echo e($project->id); ?>" role="tabpanel"
    aria-labelledby="proformas-tab<?php echo e($project->id); ?>">
    <div class="card mb-4">

        <div class="card-header  text-white">
            <h5><?php echo e($project->name); ?> Proformas</h5>
        </div>

        <!-- Tabs for Proforma Types -->
        <div class="card-body">
            <ul class="nav nav-tabs" id="mainProformaTabs<?php echo e($project->id); ?>" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="buyer-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        href="#buyerProforma<?php echo e($project->id); ?>" role="tab"
                        aria-controls="buyerProforma<?php echo e($project->id); ?>" aria-selected="true">
                        <i class="bi bi-person"></i> Aluminium Proforma
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="seller-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        href="#sellerProforma<?php echo e($project->id); ?>" role="tab"
                        aria-controls="sellerProforma<?php echo e($project->id); ?>" aria-selected="false">
                        <i class="bi bi-people"></i> Sales Proforma
                    </a>
                </li>
            </ul>

            <!-- Tab Content for Buyer and Seller Proformas -->
            <div class="tab-content mt-3" id="mainProformaTabContent<?php echo e($project->id); ?>">
                <div class="tab-pane fade show active" id="buyerProforma<?php echo e($project->id); ?>" role="tabpanel"
                    aria-labelledby="buyer-tab<?php echo e($project->id); ?>">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="proformaTabs<?php echo e($project->id); ?>" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="profile-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                                    href="#profileProforma<?php echo e($project->id); ?>" role="tab"
                                    aria-controls="profileProforma<?php echo e($project->id); ?>" aria-selected="true">
                                    <i class="bi bi-box-seam"></i> Aluminium Profile Proforma
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="accessories-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                                    href="#accessoriesProforma<?php echo e($project->id); ?>" role="tab"
                                    aria-controls="accessoriesProforma<?php echo e($project->id); ?>" aria-selected="false">
                                    <i class="bi bi-gear"></i> Accessories Proforma
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="work-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                                    href="#workProforma<?php echo e($project->id); ?>" role="tab"
                                    aria-controls="workProforma<?php echo e($project->id); ?>" aria-selected="false">
                                    <i class="bi bi-briefcase"></i> Work Proforma
                                </a>
                            </li>
                        </ul>

                        <div class="tab-content mt-3" id="proformaTabContent<?php echo e($project->id); ?>">
                            <!-- Aluminium Profile Proforma Content -->
                            <?php echo $__env->make('tab_components.aluminiumProfileTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <!-- Accessories Proforma Content -->
                            <?php echo $__env->make('tab_components.aluminiumAccessoriesTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <!-- Work Proforma Content -->
                            <?php echo $__env->make('tab_components.workProformaTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>

                <?php echo $__env->make('tab_components.sellerProformaTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>






</div>







</div>
</div>
</div>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/proformaTab.blade.php ENDPATH**/ ?>