<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2><?php echo e($customer->name); ?>'s Project</h2>
            </div>
            
        </div>
    </div>



    



    <div class="card mb-4">
        <div
            class="card-header 
            <?php echo e($project->status === 'completed' ? 'bg-success' : ($project->status === 'cancelled' ? 'bg-danger' : ($project->status === 'pending' ? 'bg-warning' : 'bg-secondary'))); ?> 
            text-white d-flex justify-content-between align-items-center">
            <h4><?php echo e($project->name); ?></h4>
            <!-- Edit Button -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proforma-edit')): ?>
                <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#editProjectModal<?php echo e($project->id); ?>">
                    Edit
                </button>
            <?php endif; ?>
        </div>

        <!-- Edit Project Modal -->
        <div class="modal fade" id="editProjectModal<?php echo e($project->id); ?>" tabindex="-1"
            aria-labelledby="editProjectModalLabel<?php echo e($project->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editProjectModalLabel<?php echo e($project->id); ?>">Edit Project</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="name">Project Name</label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($project->name); ?>"
                                    required>
                            </div>

                            <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">


                            <div class="form-group mt-3">
                                <label for="starting_date">Starting Date</label>
                                <input type="date" name="starting_date" class="form-control"
                                    value="<?php echo e($project->starting_date); ?>" required>
                            </div>

                            <div class="form-group mt-3">
                                <label for="ending_date">Ending Date</label>
                                <input type="date" name="ending_date" class="form-control"
                                    value="<?php echo e($project->ending_date); ?>">
                            </div>

                            <div class="form-group mt-3">
                                <label for="description">Description</label>
                                <textarea name="description" class="form-control"><?php echo e($project->description); ?></textarea>
                            </div>

                            <div class="form-group mt-3">
                                <label for="location">Location</label>
                                <input type="text" name="location" class="form-control"
                                    value="<?php echo e($project->location); ?>">
                            </div>

                            <div class="form-group mt-3">
                                <label for="total_price">Total Price</label>
                                <input type="number" name="total_price" class="form-control"
                                    value="<?php echo e($project->total_price); ?>">
                            </div>

                            <div class="form-group mt-3">
                                <label for="status">Status</label>
                                <select name="status" class="form-control">
                                    <option value="pending" <?php echo e($project->status === 'pending' ? 'selected' : ''); ?>>
                                        Pending</option>
                                    <option value="completed" <?php echo e($project->status === 'completed' ? 'selected' : ''); ?>>
                                        Completed</option>
                                    <option value="cancelled" <?php echo e($project->status === 'cancelled' ? 'selected' : ''); ?>>
                                        Cancelled</option>
                                </select>
                            </div>


                            <div class="form-group">
                                <label for="services">Select Service Details</label>
                                <div class="services">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="service-category">
                                            <strong><?php echo e($service->name); ?></strong> <!-- Service Name -->
                                            <div class="service-details">
                                                <?php $__currentLoopData = $service->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox"
                                                            name="service_detail_ids[]" value="<?php echo e($serviceDetail->id); ?>"
                                                            
                                                            <?php echo e(isset($project) && $project->serviceDetails->contains($serviceDetail->id) ? 'checked' : ''); ?>>
                                                        <label class="form-check-label">
                                                            <?php echo e($serviceDetail->detail_name); ?>

                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <hr>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Tabs for Project Details -->
            <ul class="nav nav-tabs" id="projectTab<?php echo e($project->id); ?>" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="project-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#project<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="project<?php echo e($project->id); ?>" aria-selected="true">Project</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="quantity-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#quantity<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="quantity<?php echo e($project->id); ?>" aria-selected="false">Quantity</button>
                </li>



                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="expenses-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#expenses<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="expenses<?php echo e($project->id); ?>" aria-selected="false">Costs</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="proformas-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#proformas<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="proformas<?php echo e($project->id); ?>" aria-selected="false">Proformas</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="images-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#images<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="images<?php echo e($project->id); ?>" aria-selected="false">Images</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="daily-tasks-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                        data-bs-target="#daily-tasks<?php echo e($project->id); ?>" type="button" role="tab"
                        aria-controls="daily-tasks<?php echo e($project->id); ?>" aria-selected="false">
                        Daily Tasks
                    </button>
                </li>


            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="projectTabContent<?php echo e($project->id); ?>">
                <!-- Project Tab -->

                <?php echo $__env->make('tab_components/projectTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('tab_components.quantityTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('tab_components.expenseTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('tab_components.imageTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('tab_components.proformaTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="tab-pane fade" id="daily-tasks<?php echo e($project->id); ?>" role="tabpanel"
                    aria-labelledby="daily-tasks-tab<?php echo e($project->id); ?>">
                    <div>
                        <h5>Daily Tasks for Project: <?php echo e($project->name); ?></h5>

                        <!-- Form to Add New Task -->
                        <form action="<?php echo e(route('daily_activities.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="description">Task Description</label>
                                <textarea name="description" class="form-control" required></textarea>
                            </div>
                            <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('daily-activity-create')): ?>
                                <button type="submit" class="btn btn-primary mt-3">Add Task</button>
                            <?php endif; ?>
                        </form>

                        <!-- Display Existing Tasks -->
                        <h5 class="mt-4">Existing Tasks</h5>
                        <?php if($dailyActivities->count() > 0): ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $dailyActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <strong><?php echo e($activity->user->name); ?></strong>: <?php echo e($activity->description); ?>

                                        <em class="text-muted"> - <?php echo e($activity->created_at->format('M d, Y')); ?></em>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>No daily tasks added for this project yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Select all edit buttons within the accordion
                        document.querySelectorAll('.edit-proforma-btn').forEach(function(button) {
                            button.addEventListener('click', function(event) {
                                event.stopPropagation(); // Prevent the accordion from closing
                            });
                        });
                    });
                </script>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/projects/view.blade.php ENDPATH**/ ?>