<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pt-3 ml-4">
                <h2>User Management</h2>
            </div>
            <div class="pull-right mb-2 pl-4">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createUserModal">
                        Create New User
                    </button>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <div class="card mb-4">

        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>

                        <th>Address</th>
                        <th>Roles</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->address); ?></td>
                            <td>
                                <?php if(!empty($user->getRoleNames())): ?>
                                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="badge bg-success"><?php echo e($v); ?></label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </td>
                            <td>
                                <div class="btn-group" role="group" aria-label="User Actions">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                                        <a class="btn btn-info" href="#" data-bs-toggle="modal"
                                            data-bs-target="#showUserModal<?php echo e($user->id); ?>">Show</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-update')): ?>
                                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#editUserModal<?php echo e($user->id); ?>">
                                            <i class="fa-regular fa-pen-to-square"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-assign-team')): ?>
                                        <button class="btn btn-outline-success btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#addToTeamModal<?php echo e($user->id); ?>">
                                            <i class="fa-solid fa-users"></i> Add to Team
                                        </button>
                                    <?php endif; ?>
                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id], 'style' => 'display:inline']); ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                                        <button type="submit" class="btn btn-outline-danger" style="border:none;"
                                            onclick="return confirm('Are you sure you want to delete this user?')">
                                            <i class="fa-solid fa-trash-can fa-lg"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php echo Form::close(); ?>

                                </div>
                            </td>

                        </tr>
                        <!-- Add to Team Modal -->
                        <div class="modal fade" id="addToTeamModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="addToTeamModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addToTeamModalLabel<?php echo e($user->id); ?>">Add User to
                                            Team</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('users.addToTeam', $user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="teamSelect">Select Teams</label>
                                                <div id="teamSelect">
                                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox"
                                                                name="team_ids[]" value="<?php echo e($team->id); ?>"
                                                                id="team<?php echo e($team->id); ?>"
                                                                <?php if(isset($user) && $user->teams->contains($team->id)): ?> checked <?php endif; ?>>
                                                            <label class="form-check-label" for="team<?php echo e($team->id); ?>">
                                                                <?php echo e($team->name); ?>

                                                            </label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>


                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Add to Team</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


    </div>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Show User Modal -->
        <div class="modal fade" id="showUserModal<?php echo e($user->id); ?>" tabindex="-1"
            aria-labelledby="showUserModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="showUserModalLabel<?php echo e($user->id); ?>">User Details:
                            <?php echo e($user->name); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($user->phone); ?></p>
                        <p><strong>Address:</strong> <?php echo e($user->address); ?></p>
                        <p><strong>Roles:</strong></p>
                        <ul>
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($role->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit User Modal -->
        <div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1"
            aria-labelledby="editUserModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editUserModalLabel<?php echo e($user->id); ?>">Edit User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <!-- Hidden input for the user ID -->
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                            <div class="form-group">
                                <label for="edit_name">Name</label>
                                <input type="text" class="form-control" id="edit_name" name="name"
                                    value="<?php echo e($user->name); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_email">Email</label>
                                <input type="email" class="form-control" id="edit_email" name="email"
                                    value="<?php echo e($user->email); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_password">Password</label>
                                <input type="password" class="form-control" id="edit_password" name="password">
                            </div>

                            <div class="form-group">
                                <label for="edit_confirm_password">Confirm Password</label>
                                <input type="password" class="form-control" id="edit_confirm_password"
                                    name="confirm-password">
                            </div>

                            <div class="form-group">
                                <label for="edit_phone">Phone</label>
                                <input type="text" class="form-control" id="edit_phone" name="phone"
                                    value="<?php echo e($user->phone); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_address">Address</label>
                                <input type="text" class="form-control" id="edit_address" name="address"
                                    value="<?php echo e($user->address); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Role</label>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="role_<?php echo e($role->id); ?>"
                                            name="roles[]" value="<?php echo e($role->name); ?>"
                                            <?php echo e($user->roles->contains($role) ? 'checked' : ''); ?>>
                                        <label class="form-check-label"
                                            for="role_<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Create User Modal -->
    <div class="modal fade" id="createUserModal" tabindex="-1" role="dialog" aria-labelledby="createUserModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createUserModalLabel">Create New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo Form::open(['route' => 'users.store', 'method' => 'POST']); ?>

                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Name:</strong>
                                <?php echo Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Email:</strong>
                                <?php echo Form::email('email', null, ['placeholder' => 'Email', 'class' => 'form-control', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Password:</strong>
                                <?php echo Form::password('password', ['placeholder' => 'Password', 'class' => 'form-control', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Confirm Password:</strong>
                                <?php echo Form::password('confirm-password', [
                                    'placeholder' => 'Confirm Password',
                                    'class' => 'form-control',
                                    'required',
                                ]); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Phone:</strong>
                                <?php echo Form::text('phone', null, ['placeholder' => 'Phone', 'class' => 'form-control', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Address:</strong>
                                <?php echo Form::text('address', null, ['placeholder' => 'Address', 'class' => 'form-control', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Role:</strong>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <?php echo Form::checkbox('roles[]', $role->name, false, ['class' => 'form-check-input', 'id' => 'role_' . $role->id]); ?>

                                        <label class="form-check-label"
                                            for="role_<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/users/index.blade.php ENDPATH**/ ?>