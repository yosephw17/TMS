<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><?php echo e($service->name); ?></h4>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-detail-create')): ?>
                <button class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#addSpecificServiceModal">
                    <i class="bi bi-plus-circle me-2"></i>Add Specific Service
                </button>
            <?php endif; ?>

            <!-- Add Specific Service Modal -->
            <div class="modal fade" id="addSpecificServiceModal" tabindex="-1" aria-labelledby="addSpecificServiceModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title text-dark" id="addSpecificServiceModalLabel">Add New Specific Service
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php echo Form::open(['route' => 'service-details.store', 'method' => 'POST']); ?>

                            <div class="mb-3">
                                <label for="detail_name" class="form-label text-dark">Detail Name</label>
                                <input type="text" class="form-control" id="detail_name" name="detail_name" required>
                                <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label text-dark">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Specific Service</button>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body">

            <h6>Specific Service Details:</h6>
            <?php if($service->serviceDetails->isEmpty()): ?>
                <p>No specific details available for this service.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $service->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong><?php echo e($detail->detail_name); ?></strong>: <?php echo e($detail->description); ?>

                            <div>
                                <!-- Edit Button -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-detail-update')): ?>
                                    <button class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editSpecificServiceModal<?php echo e($detail->id); ?>">
                                        <i class="fa-regular fa-pen-to-square fa-lg"></i>
                                    </button>
                                <?php endif; ?>

                                <!-- Delete Button -->
                                <?php echo Form::open([
                                    'route' => ['service-details.destroy', $detail->id],
                                    'method' => 'DELETE',
                                    'style' => 'display:inline',
                                ]); ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-detail-delete')): ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this specific service?');"><i
                                            class="fa-solid fa-trash-can fa-lg"></i></button>
                                <?php endif; ?>
                                <?php echo Form::close(); ?>

                            </div>
                        </li>

                        <!-- Edit Specific Service Modal -->
                        <div class="modal fade" id="editSpecificServiceModal<?php echo e($detail->id); ?>" tabindex="-1"
                            aria-labelledby="editSpecificServiceModalLabel<?php echo e($detail->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editSpecificServiceModalLabel<?php echo e($detail->id); ?>">Edit
                                            Specific Service</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo Form::model($detail, ['route' => ['service-details.update', $detail->id], 'method' => 'PATCH']); ?>

                                        <div class="mb-3">
                                            <label for="detail_name" class="form-label">Detail Name</label>
                                            <?php echo Form::text('detail_name', null, ['class' => 'form-control', 'required']); ?>

                                        </div>
                                        <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">

                                        <div class="mb-3">
                                            <label for="description" class="form-label">Description</label>
                                            <?php echo Form::textarea('description', null, ['class' => 'form-control', 'rows' => 3]); ?>

                                        </div>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                        <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/services/show.blade.php ENDPATH**/ ?>