<!-- Expenses Tab -->
<div class="tab-pane fade" id="expenses<?php echo e($project->id); ?>" role="tabpanel"
    aria-labelledby="expenses-tab<?php echo e($project->id); ?>">
    <div class="mt-3">
        <?php if($project->purchaseRequests->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Type</th>
                            <th>Request By</th>
                            <th>Details</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $overallTotal = 0;
                        ?>

                        <?php $__currentLoopData = $project->purchaseRequests->where('status', 'approved'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $purchaseRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e(ucfirst(str_replace('_', ' ', $purchaseRequest->type))); ?></td>
                                <td><?php echo e($purchaseRequest->user->name); ?></td>

                                <?php if($purchaseRequest->type == 'material_non_stock'): ?>
                                    <td><?php echo e($purchaseRequest->non_stock_name); ?> -
                                        $<?php echo e($purchaseRequest->non_stock_price); ?></td>
                                    <td><?php echo e($purchaseRequest->non_stock_quantity); ?></td>
                                    <?php
                                        $totalPrice =
                                            $purchaseRequest->non_stock_price * $purchaseRequest->non_stock_quantity;
                                        $overallTotal += $totalPrice; // Accumulate total
                                    ?>
                                    <td>$<?php echo e(number_format($totalPrice, 2)); ?></td>
                                <?php elseif($purchaseRequest->type == 'material_stock' && $purchaseRequest->materials->count() > 0): ?>
                                    <td>
                                        <?php $__currentLoopData = $purchaseRequest->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($material->name); ?> (<?php echo e($material->unit_of_measurement); ?>)</p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $purchaseRequest->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($material->pivot->quantity); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php
                                            $stockTotal = 0;
                                        ?>
                                        <?php $__currentLoopData = $purchaseRequest->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $stockTotal += $material->pivot->quantity * $material->unit_price;
                                            ?>
                                            <p>$<?php echo e(number_format($material->pivot->quantity * $material->unit_price, 2)); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $overallTotal += $stockTotal;
                                        ?>
                                        <p>$<?php echo e(number_format($stockTotal, 2)); ?></p>
                                    </td>
                                <?php elseif($purchaseRequest->type == 'labour' || $purchaseRequest->type == 'transport'): ?>
                                    <td><?php echo e($purchaseRequest->details); ?></td>
                                    <td><?php echo e($purchaseRequest->non_stock_price); ?></td>
                                    <?php
                                        $overallTotal += $purchaseRequest->non_stock_price;
                                    ?>
                                    <td>$<?php echo e(number_format($purchaseRequest->non_stock_price, 2)); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-right"><strong>Overall Total:</strong></td>
                            <td><strong>$<?php echo e(number_format($overallTotal, 2)); ?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-right"><strong>Used Cost Percentage:</strong></td>
                            <td>
                                <?php
                                    $usedCostPercentage = $project->total_price
                                        ? ($overallTotal / $project->total_price) * 100
                                        : 0;
                                    $colorClass = 'text-danger';
                                    if ($usedCostPercentage <= 60) {
                                        $colorClass = 'text-success';
                                    } elseif ($usedCostPercentage > 60 && $usedCostPercentage <= 75) {
                                        $colorClass = 'text-warning';
                                    }
                                ?>
                                <strong
                                    class="<?php echo e($colorClass); ?>"><?php echo e(number_format($usedCostPercentage, 2)); ?>%</strong>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php else: ?>
            <p>No costs for this project yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/expenseTab.blade.php ENDPATH**/ ?>