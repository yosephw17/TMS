<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Customer Management</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-create')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createCustomerModal">
                        Create New Customer
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo e($customer->phone); ?></td>
                            <td><?php echo e($customer->address); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-view')): ?>
                                    <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                                        data-bs-target="#showCustomerModal<?php echo e($customer->id); ?>">
                                        Show
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-edit')): ?>
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editCustomerModal<?php echo e($customer->id); ?>">
                                        <i class="fa-regular fa-pen-to-square"></i>

                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-delete')): ?>
                                    <button type="button" class="btn btn-outline-danger"
                                        onclick="deleteCustomer(<?php echo e($customer->id); ?>)" style="border:none;">
                                        <i class="fa-solid fa-trash-can fa-lg"></i>
                                    </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-view')): ?>
                                    <a href="<?php echo e(route('projects.show', $customer->id)); ?>" class="btn btn-sm btn-primary">
                                        View Projects
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Show Customer Modal -->
                        <div class="modal fade" id="showCustomerModal<?php echo e($customer->id); ?>" tabindex="-1"
                            aria-labelledby="showCustomerModalLabel<?php echo e($customer->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="showCustomerModalLabel<?php echo e($customer->id); ?>">Show
                                            Customer
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Name:</strong> <?php echo e($customer->name); ?></p>
                                        <p><strong>Phone:</strong> <?php echo e($customer->phone); ?></p>
                                        <p><strong>Address:</strong> <?php echo e($customer->address); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Edit Customer Modal -->
                        <div class="modal fade" id="editCustomerModal<?php echo e($customer->id); ?>" tabindex="-1"
                            aria-labelledby="editCustomerModalLabel<?php echo e($customer->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editCustomerModalLabel<?php echo e($customer->id); ?>">Edit
                                            Customer</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('customers.update', $customer->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="form-group">
                                                <strong>Name:</strong>
                                                <input type="text" name="name" value="<?php echo e($customer->name); ?>"
                                                    class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <strong>Phone:</strong>
                                                <input type="text" name="phone" value="<?php echo e($customer->phone); ?>"
                                                    class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <strong>Address:</strong>
                                                <input type="text" name="address" value="<?php echo e($customer->address); ?>"
                                                    class="form-control" required>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Customer Modal -->
    <div class="modal fade" id="createCustomerModal" tabindex="-1" aria-labelledby="createCustomerModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createCustomerModalLabel">Create New Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('customers.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <strong>Name:</strong>
                            <input type="text" name="name" placeholder="Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <strong>Phone:</strong>
                            <input type="text" name="phone" placeholder="Phone" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <strong>Address:</strong>
                            <input type="text" name="address" placeholder="Address" class="form-control" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function deleteCustomer(customerId) {
        if (confirm("Are you sure to delete this customer?")) {
            fetch(`customers/${customerId}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert("Failed to delete customer.");
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/customers/index.blade.php ENDPATH**/ ?>