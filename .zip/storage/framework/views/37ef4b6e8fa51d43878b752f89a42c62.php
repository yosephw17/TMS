<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Stock: <?php echo e($stock->name); ?> (<?php echo e($stock->location); ?>)</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-add-material')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addMaterialModal">
                        Add Material
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Material Name</th>
                        <th>Color</th>
                        <th>Quantity</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stock->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($material->name); ?></td>
                            <td><?php echo e($material->color); ?></td>
                            <td><?php echo e($material->pivot->quantity); ?> </td>
                            <td <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-remove-material')): ?>
                                    <button class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#removeMaterialModal<?php echo e($material->id); ?>">
                                        Remove
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Modal for Removing Material -->
                        </td>
                        </tr>
                        <div class="modal fade" id="removeMaterialModal<?php echo e($material->id); ?>" tabindex="-1"
                            aria-labelledby="removeMaterialModalLabel<?php echo e($material->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="removeMaterialModalLabel<?php echo e($material->id); ?>">Remove
                                            Material Quantity</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('stocks.removeMaterial', [$stock->id, $material->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <div class="form-group">
                                                <label for="quantity">Quantity to Remove</label>
                                                <input type="number" name="quantity" class="form-control" min="1"
                                                    max="<?php echo e($material->pivot->quantity); ?>" required>
                                            </div>
                                            <div class="text-center mt-3">
                                                <button type="submit" class="btn btn-danger">Remove</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Material Modal -->
    <div class="modal fade" id="addMaterialModal" tabindex="-1" aria-labelledby="addMaterialModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMaterialModalLabel">Add Materials to Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('stocks.addMaterial', $stock->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="materials">Materials</label>
                            <div class="row">
                                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="materials[]"
                                                value="<?php echo e($material->id); ?>" id="material<?php echo e($material->id); ?>">
                                            <label class="form-check-label" for="material<?php echo e($material->id); ?>">
                                                <?php echo e($material->name); ?>

                                                <?php if($material->color): ?>
                                                    (<?php echo e($material->color); ?>)
                                                <?php endif; ?>
                                            </label>
                                            <input type="number" name="quantities[<?php echo e($material->id); ?>]"
                                                class="form-control mt-2" placeholder="Quantity" min="1">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/stocks/show.blade.php ENDPATH**/ ?>