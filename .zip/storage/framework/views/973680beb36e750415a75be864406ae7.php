<div class="tab-pane fade" id="quantity<?php echo e($project->id); ?>" role="tabpanel"
    aria-labelledby="quantity-tab<?php echo e($project->id); ?>">
    <div class="mt-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material-create')): ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                data-bs-target="#selectMaterialsModal<?php echo e($project->id); ?>">
                Add Materials
            <?php endif; ?>
        </button>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-material-print')): ?>
            <a href="<?php echo e(route('projects.materials.print', $project->id)); ?>" class="btn btn-secondary" target="_blank">
                <i class="fas fa-print"></i>
                Print
            </a>
        <?php endif; ?>

    </div>

    <div class="mt-3">
        <h5>Materials</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Material Name</th>
                    <th>Color</th>
                    <th>Quantity</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $project->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($material->name); ?></td>
                        <td><?php echo e($material->color); ?></td>
                        <td><?php echo e($material->pivot->quantity); ?></td>
                        <td>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-material-edit')): ?>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                    data-bs-target="#editMaterialModal<?php echo e($material->id); ?>-<?php echo e($project->id); ?>">
                                    <i class="fa-regular fa-pen-to-square"></i>

                                </button>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-material-delete')): ?>
                                <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                    data-bs-target="#deleteMaterialModal<?php echo e($material->id); ?>-<?php echo e($project->id); ?>">
                                    <i class="fa-solid fa-trash-can fa-lg"></i>

                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__currentLoopData = $project->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Edit Material Modal -->
    <div class="modal fade" id="editMaterialModal<?php echo e($material->id); ?>-<?php echo e($project->id); ?>" tabindex="-1"
        aria-labelledby="editMaterialLabel<?php echo e($material->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('projectMaterials.update', [$project->id, $material->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editMaterialLabel<?php echo e($material->id); ?>">Edit
                            Material Quantity</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" name="quantity" class="form-control"
                                value="<?php echo e($material->pivot->quantity); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <!-- Delete Material Modal -->
    <div class="modal fade" id="deleteMaterialModal<?php echo e($material->id); ?>-<?php echo e($project->id); ?>" tabindex="-1"
        aria-labelledby="deleteMaterialLabel<?php echo e($material->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('projects.materials.destroy', [$project->id, $material->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteMaterialLabel<?php echo e($material->id); ?>">Confirm
                            Delete</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete this material from the project?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Select Materials Modal -->
<div class="modal fade" id="selectMaterialsModal<?php echo e($project->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="selectMaterialsModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('projects.addMaterials', $project->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="selectMaterialsModalLabel">Select Materials for
                        Project</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="materials">Materials</label>
                        <div class="row">
                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="materials[]"
                                            value="<?php echo e($material->id); ?>" id="material<?php echo e($material->id); ?>">
                                        <label class="form-check-label" for="material<?php echo e($material->id); ?>">
                                            <?php echo e($material->name); ?> <?php if($material->color): ?>
                                                (<?php echo e($material->color); ?>)
                                            <?php endif; ?>
                                        </label>
                                        <input type="number" name="quantities[<?php echo e($material->id); ?>]"
                                            class="form-control mt-2" placeholder="Quantity" min="1">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Materials</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/tab_components/quantityTab.blade.php ENDPATH**/ ?>