<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Teams</h2>

        <!-- Button to trigger modal to add new team -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team-create')): ?>
            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addTeamModal">Add Team</button>
        <?php endif; ?>

        <!-- Team List Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($team->name); ?></td>
                        <td><?php echo e($team->description); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <!-- Show Button -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team-view')): ?>
                                    <button class="btn btn-info" data-bs-toggle="modal"
                                        data-bs-target="#showTeamModal<?php echo e($team->id); ?>">Show</button>
                                <?php endif; ?>

                                <!-- Edit Button -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team-update')): ?>
                                    <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#editTeamModal<?php echo e($team->id); ?>"><i
                                            class="fa-regular fa-pen-to-square"></i></button>
                                <?php endif; ?>

                            </div>
                            <!-- Delete Form -->
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['teams.destroy', $team->id], 'style' => 'display:inline']); ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team-delete')): ?>
                                <button type="submit" class="btn btn-outline-danger"
                                    onclick="return confirm('Are you sure you want to delete this team?')"> <i
                                        class="fa-solid fa-trash-can fa-lg"></i>
                                </button>
                            <?php endif; ?>
                            <?php echo Form::close(); ?>

    </div>
    </td>
    </tr>

    <!-- Show Team Modal -->
    <div class="modal fade" id="showTeamModal<?php echo e($team->id); ?>" tabindex="-1"
        aria-labelledby="showTeamModalLabel<?php echo e($team->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Team Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Team Information -->
                    <p><strong>Name:</strong> <?php echo e($team->name); ?></p>
                    <p><strong>Description:</strong> <?php echo e($team->description); ?></p>

                    <!-- List of Users Assigned to this Team -->
                    <p><strong>Users Assigned:</strong></p>
                    <?php if($team->users->count() > 0): ?>
                        <ul>
                            <?php $__currentLoopData = $team->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($user->name); ?> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p>No users are assigned to this team.</p>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Team Modal -->
    <div class="modal fade" id="editTeamModal<?php echo e($team->id); ?>" tabindex="-1"
        aria-labelledby="editTeamModalLabel<?php echo e($team->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Team</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('teams.update', $team->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($team->name); ?>" required>
                        </div>
                        <div class="form-group mt-2">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control"><?php echo e($team->description); ?></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-warning">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>

    <!-- Add Team Modal -->
    <div class="modal fade" id="addTeamModal" tabindex="-1" aria-labelledby="addTeamModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Team</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('teams.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/teams/index.blade.php ENDPATH**/ ?>