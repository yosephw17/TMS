<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Print Materials - <?php echo e($project->name); ?></title>
    <link href="<?php echo e(asset('css/print.css')); ?>" rel="stylesheet" />
</head>

<body>
    <div class="container">
        <header>
            <div>
                <h1>Materials List for Project: <?php echo e($project->name); ?></h1>
                <p>Date: <?php echo e(\Carbon\Carbon::parse($project->created_at)->format('d/m/Y')); ?>


            </div>
            <?php if($companyInfo->logo && file_exists(public_path('storage/' . $companyInfo->logo))): ?>
                <img src="<?php echo e(asset('storage/' . $companyInfo->logo)); ?>" alt="<?php echo e($companyInfo->name); ?> Logo"
                    class="company-logo" />
            <?php endif; ?>
        </header>

        <div class="details-container">
            <div class="company-details">
                <p><strong><?php echo e($companyInfo->name); ?></strong></p>
                <p>Tel: <?php echo e($companyInfo->phone); ?></p>
                <p>Fax: <?php echo e($companyInfo->fax ?? 'N/A'); ?></p>
                <p>PO Box: <?php echo e($companyInfo->po_box); ?></p>
                <p>Email: <?php echo e($companyInfo->email); ?></p>
            </div>
            <div class="project-details">
                <p><strong>Project: <?php echo e($project->name); ?></strong></p>
                <p><strong>Location: </strong><?php echo e($project->location); ?></p>
            </div>
        </div>



        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Material Name</th>
                    <th>Color</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $project->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($material->name); ?></td>
                        <td><?php echo e($material->color); ?></td>
                        <td><?php echo e($material->pivot->quantity); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


        <img src="<?php echo e(asset('images/qr-code.png')); ?>" alt="QR Code" class="qr-code" />
    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/print/materialsPrint.blade.php ENDPATH**/ ?>