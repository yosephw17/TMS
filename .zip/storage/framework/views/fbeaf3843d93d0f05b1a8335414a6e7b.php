<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">
            <div class="sb-sidenav-menu-heading">Core</div>


            <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                Dashboard
            </a>


            <div class="sb-sidenav-menu-heading">Management</div>

            <!-- Customers -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-customer')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('customers.index', 'projects.show') ? 'active' : ''); ?>"
                    href="<?php echo e(route('customers.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-address-book"></i></div>
                    Customers
                </a>
            <?php endif; ?>

            <!-- Projects -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-project')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('projects.index', 'projects.view') ? 'active' : ''); ?>"
                    href="<?php echo e(route('projects.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-project-diagram"></i></div>
                    Projects
                </a>
            <?php endif; ?>
            <!-- Purchase Requests -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-purchase-request')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('purchase_requests.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('purchase_requests.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-invoice"></i></div>
                    Requests
                </a>
            <?php endif; ?>
            <!-- Materials -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-material')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('materials.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('materials.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-boxes"></i></div>
                    Materials
                </a>
            <?php endif; ?>




            <!-- Stock -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-stock')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('stocks.index', 'stocks.show') ? 'active' : ''); ?>"
                    href="<?php echo e(route('stocks.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-warehouse"></i></div>
                    Stock
                </a>
            <?php endif; ?>
            <!-- Stock -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-seller')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('sellers.index', 'proforma_images.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('sellers.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                    Sellers
                </a>
            <?php endif; ?>

            <!-- Settings -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-setting')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('settings.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('settings.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-sliders-h"></i></div>
                    Settings
                </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-service')): ?>
                <a class="nav-link <?php echo e(request()->routeIs('services.index', 'services.show') ? 'active' : ''); ?>"
                    href="<?php echo e(route('services.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-concierge-bell"></i></div>
                    Services
                </a>
            <?php endif; ?>



            <!-- User Management -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-user')): ?>
                <a class="nav-link collapsed <?php echo e(request()->routeIs(['users.index', 'roles.index', 'permissions.index', 'teams.index']) ? 'active' : ''); ?>"
                    href="#" data-bs-toggle="collapse" data-bs-target="#collapseUserManagement" aria-expanded="false"
                    aria-controls="collapseUserManagement">
                    <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                    User Management
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
            <?php endif; ?>
            <div class="collapse" id="collapseUserManagement" aria-labelledby="headingUserManagement"
                data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-user')): ?>
                        <a class="nav-link <?php echo e(request()->routeIs('users.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('users.index')); ?>"><i class="fas fa-user"></i> Users</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-role')): ?>
                        <a class="nav-link <?php echo e(request()->routeIs('roles.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('roles.index')); ?>"><i class="fas fa-user-tag"></i> Roles</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-permission')): ?>
                        <a class="nav-link <?php echo e(request()->routeIs('permissions.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('permissions.index')); ?>"><i class="fas fa-user-shield"></i>
                            Permissions</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-team')): ?>
                        <!-- Teams -->
                        <a class="nav-link" href="<?php echo e(route('teams.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                            Teams
                        </a>
                    <?php endif; ?>
                </nav>

            </div>
        </div>
    </div>


</nav>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>