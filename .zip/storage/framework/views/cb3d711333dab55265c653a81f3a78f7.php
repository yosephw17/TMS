<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Projects for <?php echo e($customer->name); ?></h2>
            </div>
            <div class="pull-right">
                <!-- Button to trigger modal -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-create')): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#serviceModal">
                        Add Project
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="serviceModal" tabindex="-1" aria-labelledby="serviceModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('projects.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Project Name and other fields -->
                        <div class="form-group mb-3">
                            <label for="name">Project Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <!-- Starting Date -->
                        <div class="form-group mb-3">
                            <label for="starting_date">Starting Date</label>
                            <input type="date" name="starting_date" class="form-control" required>
                        </div>

                        <!-- Ending Date -->
                        <div class="form-group mb-3">
                            <label for="ending_date">Ending Date</label>
                            <input type="date" name="ending_date" class="form-control" required>
                        </div>

                        <!-- Hidden customer ID input -->
                        <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">

                        <!-- Description -->
                        <div class="form-group mb-3">
                            <label for="description">Project Description</label>
                            <textarea name="description" class="form-control" rows="3" required></textarea>
                        </div>

                        <!-- Location -->
                        <div class="form-group mb-3">
                            <label for="location">Location</label>
                            <input type="text" name="location" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="services">Select Service Details</label>
                            <div class="services">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="service-category">
                                        <strong><?php echo e($service->name); ?></strong> <!-- Service Name -->
                                        <div class="service-details">
                                            <?php $__currentLoopData = $service->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox"
                                                        name="service_detail_ids[]" value="<?php echo e($serviceDetail->id); ?>"
                                                        <?php echo e(isset($project) && $project->serviceDetails->contains($serviceDetail->id) ? 'checked' : ''); ?>>
                                                    <label class="form-check-label">
                                                        <?php echo e($serviceDetail->detail_name); ?>

                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <hr>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="teams">Select Teams</label>
                            <div id="teamSelect">
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="team_ids[]"
                                            value="<?php echo e($team->id); ?>" id="team<?php echo e($team->id); ?>"
                                            <?php echo e(isset($project) && $project->teams->contains($team->id) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="team<?php echo e($team->id); ?>">
                                            <?php echo e($team->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Save Project</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div
                class="card-header 
            <?php echo e($project->status === 'completed' ? 'bg-success' : ($project->status === 'cancelled' ? 'bg-danger' : ($project->status === 'pending' ? 'bg-warning' : 'bg-secondary'))); ?> 
            text-white d-flex justify-content-between align-items-center">
                <h4><?php echo e($project->name); ?></h4>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-edit')): ?>
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal"
                        data-bs-target="#editProjectModal<?php echo e($project->id); ?>">
                        Edit
                    </button>
                <?php endif; ?>
            </div>

            <div class="modal fade" id="editProjectModal<?php echo e($project->id); ?>" tabindex="-1"
                aria-labelledby="editProjectModalLabel<?php echo e($project->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editProjectModalLabel<?php echo e($project->id); ?>">Edit Project</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="name">Project Name</label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo e($project->name); ?>" required>
                                </div>

                                <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">

                                <div class="form-group mt-3">
                                    <label for="starting_date">Starting Date</label>
                                    <input type="date" name="starting_date" class="form-control"
                                        value="<?php echo e($project->starting_date); ?>" required>
                                </div>

                                <div class="form-group mt-3">
                                    <label for="ending_date">Ending Date</label>
                                    <input type="date" name="ending_date" class="form-control"
                                        value="<?php echo e($project->ending_date); ?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="description">Description</label>
                                    <textarea name="description" class="form-control"><?php echo e($project->description); ?></textarea>
                                </div>

                                <div class="form-group mt-3">
                                    <label for="location">Location</label>
                                    <input type="text" name="location" class="form-control"
                                        value="<?php echo e($project->location); ?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="total_price">Total Price</label>
                                    <input type="number" name="total_price" class="form-control"
                                        value="<?php echo e($project->total_price); ?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="status">Status</label>
                                    <select name="status" class="form-control">
                                        <option value="pending" <?php echo e($project->status === 'pending' ? 'selected' : ''); ?>>
                                            Pending</option>
                                        <option value="completed"
                                            <?php echo e($project->status === 'completed' ? 'selected' : ''); ?>>Completed</option>
                                        <option value="cancelled"
                                            <?php echo e($project->status === 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                    </select>
                                </div>

                                <!-- Services (Select Service Details) -->
                                <div class="form-group">
                                    <label for="services">Select Service Details</label>
                                    <div class="services">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="service-category">
                                                <strong><?php echo e($service->name); ?></strong> <!-- Service Name -->
                                                <div class="service-details">
                                                    <?php $__currentLoopData = $service->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox"
                                                                name="service_detail_ids[]"
                                                                value="<?php echo e($serviceDetail->id); ?>"
                                                                <?php echo e(isset($project) && $project->serviceDetails->contains($serviceDetail->id) ? 'checked' : ''); ?>>
                                                            <label
                                                                class="form-check-label"><?php echo e($serviceDetail->detail_name); ?></label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <hr>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <!-- Team Selection -->
                                <div class="form-group mt-3">
                                    <label for="teams">Select Teams</label>
                                    <div class="teams">
                                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="team_ids[]"
                                                    value="<?php echo e($team->id); ?>"
                                                    <?php echo e(isset($project) && $project->teams->contains($team->id) ? 'checked' : ''); ?>>
                                                <label class="form-check-label"><?php echo e($team->name); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


            <div class="card-body">
                <ul class="nav nav-tabs" id="projectTab<?php echo e($project->id); ?>" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="project-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#project<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="project<?php echo e($project->id); ?>" aria-selected="true">Project</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="quantity-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#quantity<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="quantity<?php echo e($project->id); ?>" aria-selected="false">Quantity</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="expenses-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#expenses<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="expenses<?php echo e($project->id); ?>" aria-selected="false">Costs</button>
                    </li>

                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="proformas-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#proformas<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="proformas<?php echo e($project->id); ?>" aria-selected="false">Proformas</button>
                    </li>

                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="images-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#images<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="images<?php echo e($project->id); ?>" aria-selected="false">Images</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="task-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                            data-bs-target="#tasks<?php echo e($project->id); ?>" type="button" role="tab"
                            aria-controls="tasks<?php echo e($project->id); ?>" aria-selected="false">Daily Tasks</button>
                    </li>
                </ul>

                <div class="tab-content" id="projectTabContent<?php echo e($project->id); ?>">
                    <div class="tab-pane fade show active" id="project<?php echo e($project->id); ?>" role="tabpanel"
                        aria-labelledby="project-tab<?php echo e($project->id); ?>">
                        <div class="mt-3">

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-calendar-alt"></i> Starting Date:
                                </strong>
                                <p class="lead"><?php echo e(\Carbon\Carbon::parse($project->starting_date)->format('F d, Y')); ?>

                                </p>
                            </div>

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-calendar-check"></i> Ending Date:
                                </strong>
                                <p class="lead">
                                    <?php echo e($project->ending_date ? \Carbon\Carbon::parse($project->ending_date)->format('F d, Y') : 'Ongoing'); ?>

                                </p>
                            </div>

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-align-left"></i> Description:
                                </strong>
                                <p class="lead"><?php echo e($project->description); ?></p>
                            </div>

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-map-marker-alt"></i> Location:
                                </strong>
                                <p class="lead"><?php echo e($project->location); ?></p>
                            </div>

                            \ <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-concierge-bell"></i> Services Included:
                                </strong>
                                <?php if($project->serviceDetails->count() > 0): ?>
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $project->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php echo e($serviceDetail->detail_name); ?> (under
                                                <?php echo e($serviceDetail->service->name); ?>)
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">None</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-users"></i> Team:
                                </strong>
                                <?php if($project->teams->count() > 0): ?>
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $project->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php echo e($team->name); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">None</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <strong class="font-weight-bold mb-1">
                                    <i class="fas fa-tasks"></i> Status:
                                </strong>
                                <p class="lead">
                                    <span
                                        class="<?php echo e($project->status == 'completed' ? 'text-success' : ($project->status == 'canceled' ? 'text-danger' : 'text-warning')); ?>">
                                        <?php echo e(ucfirst($project->status)); ?>

                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>


                    <?php echo $__env->make('tab_components.quantityTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    

                    


                    

                    
                    <?php echo $__env->make('tab_components.expenseTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Images Tab -->
                    <?php echo $__env->make('tab_components.imageTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- Proformas Tab -->

                    <?php
                        $profileProformas = $project->proformas()->where('type', 'aluminium_profile')->get();
                        $accessoriesProformas = $project->proformas()->where('type', 'aluminium_accessories')->get();
                        $workProformas = $project->proformas()->where('type', 'work')->get();
                        $dailyActivities = $project->dailyActivities;
                    ?>
                    <!-- Proformas Tab -->
                    <div class="tab-pane fade" id="proformas<?php echo e($project->id); ?>" role="tabpanel"
                        aria-labelledby="proformas-tab<?php echo e($project->id); ?>">
                        <div class="card mb-4">

                            <!-- Card Header -->
                            <div class="card-header text-white">
                                <h5><?php echo e($project->name); ?> Proformas</h5>
                            </div>

                            <!-- Tabs for Proforma Types -->
                            <div class="card-body">
                                <ul class="nav nav-tabs" id="proformaMainTabs<?php echo e($project->id); ?>" role="tablist">
                                    <!-- Buyer Proforma Tab -->
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="buyer-tab<?php echo e($project->id); ?>"
                                            data-bs-toggle="tab" href="#buyerProforma<?php echo e($project->id); ?>" role="tab"
                                            aria-controls="buyerProforma<?php echo e($project->id); ?>" aria-selected="true">
                                            <i class="bi bi-cart"></i> Aluminium Proforma
                                        </a>
                                    </li>

                                    <!-- Seller Proforma Tab -->
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="seller-tab<?php echo e($project->id); ?>" data-bs-toggle="tab"
                                            href="#sellerProforma<?php echo e($project->id); ?>" role="tab"
                                            aria-controls="sellerProforma<?php echo e($project->id); ?>" aria-selected="false">
                                            <i class="bi bi-person-badge"></i> Sales Proforma
                                        </a>
                                    </li>
                                </ul>

                                <!-- Main Tab Content -->
                                <div class="tab-content mt-3" id="proformaMainTabContent<?php echo e($project->id); ?>">
                                    <!-- Buyer Proforma Content -->
                                    <div class="tab-pane fade show active" id="buyerProforma<?php echo e($project->id); ?>"
                                        role="tabpanel" aria-labelledby="buyer-tab<?php echo e($project->id); ?>">
                                        <ul class="nav nav-tabs" id="proformaTabs<?php echo e($project->id); ?>" role="tablist">
                                            <li class="nav-item" role="presentation">
                                                <a class="nav-link active" id="profile-tab<?php echo e($project->id); ?>"
                                                    data-bs-toggle="tab" href="#profileProforma<?php echo e($project->id); ?>"
                                                    role="tab" aria-controls="profileProforma<?php echo e($project->id); ?>"
                                                    aria-selected="true">
                                                    <i class="bi bi-box-seam"></i> Aluminium Profile Proforma
                                                </a>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <a class="nav-link" id="accessories-tab<?php echo e($project->id); ?>"
                                                    data-bs-toggle="tab" href="#accessoriesProforma<?php echo e($project->id); ?>"
                                                    role="tab" aria-controls="accessoriesProforma<?php echo e($project->id); ?>"
                                                    aria-selected="false">
                                                    <i class="bi bi-gear"></i> Accessories Proforma
                                                </a>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <a class="nav-link" id="work-tab<?php echo e($project->id); ?>"
                                                    data-bs-toggle="tab" href="#workProforma<?php echo e($project->id); ?>"
                                                    role="tab" aria-controls="workProforma<?php echo e($project->id); ?>"
                                                    aria-selected="false">
                                                    <i class="bi bi-briefcase"></i> Work Proforma
                                                </a>
                                            </li>
                                        </ul>

                                        <!-- Buyer Proforma Tab Content -->
                                        <div class="tab-content mt-3" id="proformaTabContent<?php echo e($project->id); ?>">
                                            <?php echo $__env->make('tab_components.aluminiumProfileTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php echo $__env->make('tab_components.aluminiumAccessoriesTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php echo $__env->make('tab_components.workProformaTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>

                                    <!-- Seller Proforma Content -->
                                    <?php echo $__env->make('tab_components.sellerProformaTab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Daily Tasks Tab -->
                    <div class="tab-pane fade" id="tasks<?php echo e($project->id); ?>" role="tabpanel"
                        aria-labelledby="task-tab<?php echo e($project->id); ?>">
                        <!-- Daily Tasks Content -->
                        <h5>Daily Tasks for Project <?php echo e($project->name); ?></h5>

                        <!-- Form to Add New Task -->
                        <form action="<?php echo e(route('daily_activities.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="description">Task Description</label>
                                <textarea name="description" class="form-control" required></textarea>
                            </div>
                            <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                            <button type="submit" class="btn btn-primary mt-3">Add Task</button>
                        </form>

                        <!-- Display Existing Tasks -->
                        <ul class="mt-4">
                            <?php $__currentLoopData = $project->dailyActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <strong><?php echo e($activity->user->name); ?></strong>: <?php echo e($activity->description); ?>

                                    <em><?php echo e($activity->created_at->format('M d, Y')); ?></em>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/projects/show.blade.php ENDPATH**/ ?>