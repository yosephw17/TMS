<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>Services</h2>
                    </div>
                    <div class="pull-right mb-3">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-create')): ?>
                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#createServiceModal">
                                Create New Service
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Details</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($service->name); ?></td>
                        <td><?php echo e($service->details); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Service Actions">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-view')): ?>
                                    <button class="btn btn-info" data-bs-toggle="modal"
                                        data-bs-target="#serviceModal<?php echo e($service->id); ?>"
                                        onclick="showServiceDetails(<?php echo e($service->id); ?>)">Show</button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-update')): ?>
                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editServiceModal<?php echo e($service->id); ?>">
                                        <i class="fa-regular fa-pen-to-square fa-lg"></i>
                                    </button>
                                <?php endif; ?>
                                

                                <?php echo Form::open([
                                    'method' => 'DELETE',
                                    'route' => ['services.destroy', $service->id],
                                    'style' => 'display:inline',
                                ]); ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-delete')): ?>
                                    <button type="submit" class="btn btn-outline-danger" style="border:none;"
                                        onclick="return confirm('Are you sure you want to delete the service?');">
                                        <i class="fa-solid fa-trash-can fa-lg"></i>
                                    </button>
                                <?php endif; ?>

                                <?php echo Form::close(); ?>

                            </div>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-detail-view')): ?>
                                <button type="button"class="btn btn-primary"
                                    onclick="window.location='<?php echo e(route('services.show', $service->id)); ?>'">
                                    View
                                </button>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <!-- Create Service Modal -->
    <div class="modal fade" id="createServiceModal" tabindex="-1" aria-labelledby="createServiceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createServiceModalLabel">Create New Service</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo Form::open(['route' => 'services.store', 'method' => 'POST']); ?>

                    <div class="form-group">
                        <strong>Name:</strong>
                        <?php echo Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <strong>Details:</strong>
                        <?php echo Form::textarea('details', null, ['placeholder' => 'Details', 'class' => 'form-control']); ?>

                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="serviceModal<?php echo e($service->id); ?>" tabindex="-1"
            aria-labelledby="serviceModalLabel<?php echo e($service->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="serviceModalLabel<?php echo e($service->id); ?>">Service Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Name:</strong> <?php echo e($service->name); ?></p>
                        <p><strong>Details:</strong> <?php echo e($service->details); ?></p>

                        <h6>Specific Service Details:</h6>
                        <?php if($service->serviceDetails->isEmpty()): ?>
                            <p>No specific details available for this service.</p>
                        <?php else: ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $service->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <strong><?php echo e($detail->detail_name); ?></strong>: <?php echo e($detail->description); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- Edit Service Modal -->
        <div class="modal fade" id="editServiceModal<?php echo e($service->id); ?>" tabindex="-1"
            aria-labelledby="editServiceModalLabel<?php echo e($service->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editServiceModalLabel<?php echo e($service->id); ?>">Edit Service</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('services.update', $service->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-group">
                                <label for="editServiceName<?php echo e($service->id); ?>"><strong>Name:</strong></label>
                                <input type="text" name="name" value="<?php echo e($service->name); ?>"
                                    id="editServiceName<?php echo e($service->id); ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="editServiceDetails<?php echo e($service->id); ?>"><strong>Details:</strong></label>
                                <textarea name="details" id="editServiceDetails<?php echo e($service->id); ?>" class="form-control" rows="3" required><?php echo e($service->details); ?></textarea>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addServiceDetailModal<?php echo e($service->id); ?>" tabindex="-1"
            aria-labelledby="addServiceDetailModalLabel<?php echo e($service->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addServiceDetailModalLabel<?php echo e($service->id); ?>">Add Specific Service
                            for <?php echo e($service->name); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php echo Form::open(['route' => 'service-details.store', 'method' => 'POST']); ?>

                        <div class="form-group">
                            <label for="detail_name<?php echo e($service->id); ?>"><strong>Detail Name:</strong></label>
                            <input type="text" name="detail_name" id="detail_name<?php echo e($service->id); ?>"
                                class="form-control" required>
                            <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                        </div>
                        <div class="form-group">
                            <label for="description<?php echo e($service->id); ?>"><strong>Description:</strong></label>
                            <textarea name="description" id="description<?php echo e($service->id); ?>" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Add Detail</button>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/services/index.blade.php ENDPATH**/ ?>