<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Projects</h2>

        <!-- Tab Navigation -->
        <ul class="nav nav-tabs" id="projectTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="pending-tab" data-bs-toggle="tab" href="#pending" role="tab"
                    aria-controls="pending" aria-selected="true">Pending</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="completed-tab" data-bs-toggle="tab" href="#completed" role="tab"
                    aria-controls="completed" aria-selected="false">Completed</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="canceled-tab" data-bs-toggle="tab" href="#canceled" role="tab"
                    aria-controls="canceled" aria-selected="false">Canceled</a>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content mt-4" id="projectTabContent">
            <!-- Pending Projects Tab -->
            <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                <h4>Pending Projects</h4>
                <div class="table-responsive">
                    <table id="datatablesSimple" class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Starting Date</th>
                                <th>Ending Date</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pendingProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($project->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($project->starting_date)->format('F d, Y')); ?></td>
                                    <td><?php echo e($project->ending_date ? \Carbon\Carbon::parse($project->ending_date)->format('F d, Y') : 'Ongoing'); ?>

                                    </td>
                                    <td><?php echo e($project->location); ?></td>
                                    <td>
                                        <span class="badge bg-warning"><?php echo e(ucfirst($project->status)); ?></span>
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-view')): ?>
                                            <a href="<?php echo e(route('projects.view', $project->id)); ?>"
                                                class="btn btn-sm btn-primary">View</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">No pending projects available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Completed Projects Tab -->
            <div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab">
                <h4>Completed Projects</h4>
                <div class="table-responsive">
                    <table id="datatablesSimple" class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Starting Date</th>
                                <th>Ending Date</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $completedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($project->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($project->starting_date)->format('F d, Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($project->ending_date)->format('F d, Y')); ?></td>
                                    <td><?php echo e($project->location); ?></td>
                                    <td>
                                        <span class="badge bg-success"><?php echo e(ucfirst($project->status)); ?></span>
                                    </td>

                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-view')): ?>
                                            <a href="<?php echo e(route('projects.view', $project->id)); ?>"
                                                class="btn btn-sm btn-primary">View</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">No completed projects available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Canceled Projects Tab -->
            <div class="tab-pane fade" id="canceled" role="tabpanel" aria-labelledby="canceled-tab">
                <h4>Canceled Projects</h4>
                <div class="table-responsive">
                    <table id="datatablesSimple" class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Starting Date</th>
                                <th>Ending Date</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $canceledProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($project->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($project->starting_date)->format('F d, Y')); ?></td>
                                    <td><?php echo e($project->ending_date ? \Carbon\Carbon::parse($project->ending_date)->format('F d, Y') : 'Ongoing'); ?>

                                    </td>
                                    <td><?php echo e($project->location); ?></td>
                                    <td>
                                        <span class="badge bg-danger"><?php echo e(ucfirst($project->status)); ?></span>
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-view')): ?>
                                            <a href="<?php echo e(route('projects.view', $project->id)); ?>"
                                                class="btn btn-sm btn-primary">View</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">No canceled projects available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/projects/index.blade.php ENDPATH**/ ?>