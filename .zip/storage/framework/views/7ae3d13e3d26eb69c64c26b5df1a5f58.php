<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Proforma Invoice - <?php echo e($companyInfo->name); ?></title>
    <link href="<?php echo e(asset('css/print.css')); ?>" rel="stylesheet" />


</head>

<body>
    <div class="container">
        <header>
            <div>
                <h1>Proforma Invoice</h1>
                <p>Date: <?php echo e(\Carbon\Carbon::parse($proforma->date)->format('d/m/Y')); ?> | Ref No: <?php echo e($proforma->ref_no); ?>

                </p>
            </div>
            <?php if($companyInfo->logo && file_exists(public_path('storage/' . $companyInfo->logo))): ?>
                <img src="<?php echo e(asset('storage/' . $companyInfo->logo)); ?>" alt="<?php echo e($companyInfo->name); ?> Logo"
                    class="company-logo" />
            <?php endif; ?>
        </header>

        <div class="company-client-section">

            <div class="company-details">
                <p><strong><?php echo e($companyInfo->name); ?></strong></p>
                <p>Tel: <?php echo e($companyInfo->phone); ?></p>
                <p>Fax: <?php echo e($companyInfo->fax ?? 'N/A'); ?></p>
                <p>PO Box: <?php echo e($companyInfo->po_box); ?></p>
                <p>Email: <?php echo e($companyInfo->email); ?></p>
            </div>
            <div class="client-details">
                <p><strong>To: <?php echo e($proforma->customer->name); ?></strong></p>
                <p><strong>Phone: </strong><?php echo e($proforma->customer->phone); ?></p>
                <p><strong>Subject:
                    </strong><?php echo e($proforma->type === 'aluminium_profile' ? 'Aluminum Profiles' : 'Aluminum Accessories'); ?>

                </p>
            </div>
        </div>

        <div class="invoice-info">
            <div>
            </div>
            <div>

            </div>
            <div>

            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Item Description</th>
                    <th>Drawing</th>
                    <th>Unit</th>
                    <th>Color</th>
                    <th>Qty</th>
                    <th>Unit Price</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proforma->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($material->name); ?></td>
                        <td>
                            <?php if(!empty($material->symbol) && file_exists(public_path('storage/' . $material->symbol))): ?>
                                <img src="<?php echo e(asset('storage/' . $material->symbol)); ?>" alt="Symbol" width="50">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($material->unit_of_measurement); ?></td>
                        <td><?php echo e($material->color); ?></td>
                        <td><?php echo e($material->pivot->quantity); ?></td>
                        <td><?php echo e(number_format($material->unit_price, 2)); ?></td>
                        <td><?php echo e(number_format($material->pivot->total_price, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="totals">
            <p>Sub Total: <?php echo e(number_format($proforma->before_vat_total, 2)); ?></p>
            <p>VAT: <?php echo e(number_format($proforma->vat_amount, 2)); ?></p>
            <?php if(isset($proforma->discount)): ?>
                <p>Discount: <?php echo e(number_format($proforma->discount, 2)); ?></p>
            <?php endif; ?>
            <p class="total">Grand Total: <?php echo e(number_format($proforma->final_total, 2)); ?></p>
        </div>
        <footer>
            <ul class="footer-list">
                <li><strong>Price Validity:</strong> Two Days</li>
                <li><strong>Payment Terms:</strong> 100%</li>
                <li><strong>Delivery:</strong> From Store</li>
            </ul>
        </footer>
        <img src="<?php echo e(asset('images\qr-code.png')); ?>" alt="QR Code" class="qr-code" />


    </div>
    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>
<?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/print/aluminiumProfilePrint.blade.php ENDPATH**/ ?>