<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Stock Management</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-create')): ?>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createStockModal">
                        Create New Stock
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Stock Name</th>
                        <th>Location</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($stock->name); ?></td>
                            <td><?php echo e($stock->location); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-view')): ?>
                                    <a class="btn btn-sm btn-info" href="<?php echo e(route('stocks.show', $stock->id)); ?>">
                                        View
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-update')): ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#editStockModal-<?php echo e($stock->id); ?>">
                                        <i class="fa-regular fa-pen-to-square"></i> </button>
                                <?php endif; ?>

                                <form id="delete-form-<?php echo e($stock->id); ?>"
                                    action="<?php echo e(route('stocks.destroy', $stock->id)); ?>" method="POST"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-delete')): ?>
                                        <button type="button" class="btn btn-sm btn-outline-danger"
                                            onclick="if(confirm('Are you sure you want to delete this stock?')) { document.getElementById('delete-form-<?php echo e($stock->id); ?>').submit(); }">
                                            <i class="fa-solid fa-trash-can fa-lg"></i>
                                        </button>
                                    <?php endif; ?>
                                </form>

                            </td>
                        </tr>
                        <!-- Edit Stock Modal -->
                        <div class="modal fade" id="editStockModal-<?php echo e($stock->id); ?>" tabindex="-1"
                            aria-labelledby="editStockModalLabel-<?php echo e($stock->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editStockModalLabel-<?php echo e($stock->id); ?>">Edit Stock
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('stocks.update', $stock->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="form-group">
                                                <strong>Stock Name:</strong>
                                                <input type="text" name="name" value="<?php echo e($stock->name); ?>"
                                                    placeholder="Stock Name" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <strong>Location:</strong>
                                                <input type="text" name="location" value="<?php echo e($stock->location); ?>"
                                                    placeholder="Location" class="form-control" required>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Stock Modal -->
    <div class="modal fade" id="createStockModal" tabindex="-1" aria-labelledby="createStockModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createStockModalLabel">Create New Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('stocks.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <strong>Stock Name:</strong>
                            <input type="text" name="name" placeholder="Stock Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <strong>Location:</strong>
                            <input type="text" name="location" placeholder="Location" class="form-control" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bboch\OneDrive\Desktop\xampp\htdocs\teamup-management\resources\views/stocks/index.blade.php ENDPATH**/ ?>